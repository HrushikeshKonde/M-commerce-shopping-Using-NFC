package com.techcyte.nfcshop;

public class CartItem {
    String name,qty,price,id,item_total,total_qty;

    public CartItem(){

    }
    public CartItem(String id,String name, String qty) {
        this.id=id;
        this.name = name;
        this.qty = qty;
    }
    public CartItem(String id,String name, String qty, String price) {
        this.id=id;
        this.name = name;
        this.qty = qty;
        this.price = price;
    }

    public CartItem(String id,String name, String qty, String price,String item_total) {
        this.id=id;
        this.name = name;
        this.qty = qty;
        this.price = price;
        this.item_total=item_total;
    }
    public CartItem(String id,String name, String qty, String price,String item_total,String total_qty) {
        this.id=id;
        this.name = name;
        this.qty = qty;
        this.price = price;
        this.item_total=item_total;
        this.total_qty=total_qty;
    }
    public CartItem(CartItem c){
        id=c.id;
        name=c.name;
        qty=c.qty;
        price=c.price;
        item_total=c.item_total;
        total_qty=c.total_qty;
    }

    public String getId() {
        return id;
    }

    public String getTotal_qty() {
        return total_qty;
    }

    public String getItem_total() {
        return item_total;
    }

    public String getName() {
        return name;
    }

    public String getPrice() {
        return price;
    }

    public String getQty() {
        return qty;
    }
}
