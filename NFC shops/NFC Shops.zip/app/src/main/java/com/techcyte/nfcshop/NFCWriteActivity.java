package com.techcyte.nfcshop;


import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.NdefMessage;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

public class NFCWriteActivity extends AppCompatActivity {

   private NFCManager nfcMger;
    TextView des;
   private NdefMessage message = null;
    private ProgressDialog dialog;
    Tag currentTag;
    String pid="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nfc_write);

        des = (TextView) findViewById(R.id.des);


        Intent i = getIntent();
        pid = i.getStringExtra("pid");
        String pod= "Product ID : "+pid;
        des.setText(pod);

        Log.e("Prd ID :", pod);

        nfcMger = new NFCManager(this);

        message =  nfcMger.createTextMessage(pid);

        /*if (message != null) {

            dialog = new ProgressDialog(NFCWriteActivity.this);
            dialog.setMessage("Tag NFC Tag please");
            dialog.show();;
        }*/

    }

    @Override
    protected void onResume() {
        super.onResume();

        try {
            nfcMger.verifyNFC();
            //nfcMger.enableDispatch();

            Intent nfcIntent = new Intent(this, getClass());
            nfcIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, nfcIntent, 0);
            IntentFilter[] intentFiltersArray = new IntentFilter[] {};
            String[][] techList = new String[][] { { android.nfc.tech.Ndef.class.getName() }, { android.nfc.tech.NdefFormatable.class.getName() } };
            NfcAdapter nfcAdpt = NfcAdapter.getDefaultAdapter(this);
            nfcAdpt.enableForegroundDispatch(this, pendingIntent, intentFiltersArray, techList);
        }
        catch(NFCManager.NFCNotSupported nfcnsup) {
           // Snackbar.make(v, "NFC not supported", Snackbar.LENGTH_LONG).show();
            Toast.makeText(getApplicationContext(), "NFC not supported", Toast.LENGTH_LONG).show();
            //Intent in = new Intent(NFCWriteActivity.this, MainActivity.class);
           // startActivity(in);
           // finish();

        }
        catch(NFCManager.NFCNotEnabled nfcnEn) {
           // Snackbar.make(v, "NFC Not enabled", Snackbar.LENGTH_LONG).show();
            Toast.makeText(getApplicationContext(), "NFC not enabled", Toast.LENGTH_LONG).show();

        }

    }


    @Override
    protected void onPause() {
        super.onPause();
        nfcMger.disableDispatch();
    }

    @Override
    public void onNewIntent(Intent intent) {
        Log.d("Nfc", "New intent");
        // It is the time to write the tag
        currentTag = intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
        if (message != null) {
            nfcMger.writeTag(currentTag, message);
        //    dialog.dismiss();
//            Snackbar.make(v, "Tag written", Snackbar.LENGTH_LONG).show();
            Toast.makeText(getApplicationContext(), "Tag Written", Toast.LENGTH_LONG).show();
           Intent in = new Intent(NFCWriteActivity.this, AddProductActivity.class);
           startActivity(in);
           finish();

        }
        else {
            // Handle intent

        }

    }




}
