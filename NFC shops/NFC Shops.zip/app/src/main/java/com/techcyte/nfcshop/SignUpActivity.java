package com.techcyte.nfcshop;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class SignUpActivity extends AppCompatActivity {
    String phoneno,name,email,password,location;
    String admin="0";
    private EditText inputEmail, inputPassword,inputname,inputpno,inputloc;
    private Button btnSignIn, btnSignUp, btnResetPassword;
    private ProgressBar progressBar;
    private FirebaseAuth.AuthStateListener authListener;
    private FirebaseAuth auth;
    FirebaseUser u;
    DatabaseReference myref,mycart;
    private boolean isRegistrationClicked = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        //get firebase auth instance
        auth = FirebaseAuth.getInstance();
        myref=FirebaseDatabase.getInstance().getReference().child("Users");
        mycart=FirebaseDatabase.getInstance().getReference().child("Cart");

        //get current user

        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        authListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user == null) {
                    // user auth state is changed - user is null
                    // launch login activity
                    startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
                    finish();
                }
            }
        };

        btnSignIn = (Button) findViewById(R.id.sign_in_button);
        btnSignUp = (Button) findViewById(R.id.sign_up_button);
        inputname = (EditText) findViewById(R.id.fname);
        inputpno = (EditText) findViewById(R.id.phoneno);
        inputloc = (EditText) findViewById(R.id.location);
        inputEmail = (EditText) findViewById(R.id.email);
        inputPassword = (EditText) findViewById(R.id.password);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        btnResetPassword = (Button) findViewById(R.id.btn_reset_password);

        btnResetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SignUpActivity.this, ResetPasswordActivity.class));
            }
        });

        btnSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                phoneno = inputpno.getText().toString();
                name = inputname.getText().toString();
                location = inputloc.getText().toString();

                email = inputEmail.getText().toString().trim();
                password = inputPassword.getText().toString().trim();


                if (TextUtils.isEmpty(phoneno)) {
                    Toast.makeText(getApplicationContext(), "Enter Phone No!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(name)) {
                    Toast.makeText(getApplicationContext(), "Enter name!", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(email)) {
                    Toast.makeText(getApplicationContext(), "Enter email address!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(password)) {
                    Toast.makeText(getApplicationContext(), "Enter password!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(location)) {
                    Toast.makeText(getApplicationContext(), "Enter Location!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (password.length() < 6) {
                    Toast.makeText(getApplicationContext(), "Password too short, enter minimum 6 characters!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (phoneno.length() < 10 && phoneno.length() > 10) {
                    Toast.makeText(getApplicationContext(), "Enter valid mobile no !", Toast.LENGTH_SHORT).show();
                    return;
                }
                progressBar.setVisibility(View.VISIBLE);

                //create user
                auth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(SignUpActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                      //          Toast.makeText(SignUpActivity.this, "createUserWithEmail:onComplete:" + task.isSuccessful(), Toast.LENGTH_SHORT).show();
                                isRegistrationClicked = true;
                                progressBar.setVisibility(View.GONE);
                                // If sign in fails, display a message to the user. If sign in succeeds
                                // the auth state listener will be notified and logic to handle the
                                // signed in user can be handled in the listener.
                                if (!task.isSuccessful()) {
                                    Toast.makeText(SignUpActivity.this, "Authentication failed." + task.getException(),
                                            Toast.LENGTH_SHORT).show();
                                } else {
                                    sendVerificationEmail();
                                   // startActivity(new Intent(SignUpActivity.this, LoginActivity.class));
                                  //  finish();
                                }
                            }
                        });

            }
        });
    }


    private void sendVerificationEmail() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        user.sendEmailVerification()
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            // Email sent
                            u = FirebaseAuth.getInstance().getCurrentUser();

                            Users uinfo = new Users(phoneno,name,email,password,location,admin);
                            mycart.child(u.getUid()).child("isCartEmpty").setValue("1");
                            myref.child(u.getUid()).setValue(uinfo)
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                          if(task.isSuccessful()){
//                                              Toast.makeText(SignUpActivity.this, "User Added", Toast.LENGTH_SHORT).show();
                                              Toast.makeText(getApplicationContext(), "Verify Email and Login", Toast.LENGTH_LONG).show();
                                              isRegistrationClicked = false;
                                              signOut();

                                          }
                                          else{
                                              Toast.makeText(getApplicationContext(), "Cannot add Email and Login", Toast.LENGTH_LONG).show();

                                          }
                                        }
                                    });
//                            myRef.child("Name").setValue(name);
  //                          myRef.child("Email").setValue(email);
    //                        myRef.child("ID").setValue(u);
      //                      myRef.child("Password").setValue(password);
                           // Map<String, Object> us = new HashMap<>();
                          //  us.put(uid, new Users(uid, name,email,password));
                          //  myRef.updateChildren(us);



                        } else {
                            // overridePendingTransition(0, 0);
                            // finish();
                            // overridePendingTransition(0, 0);
                            // startActivity(getIntent());
                            sendVerificationEmail();
                        }
                    }
                });
    }


    //sign out method
    public void signOut() {
        auth.addAuthStateListener(authListener);

        auth.signOut();
    }

    @Override
    public void onStart() {
        super.onStart();
       // auth.addAuthStateListener(authListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (authListener != null) {
            auth.removeAuthStateListener(authListener);
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
        progressBar.setVisibility(View.GONE);
    }
}