package com.techcyte.nfcshop;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;


import static android.media.MediaRecorder.VideoSource.CAMERA;

public class AddProductActivity extends AppCompatActivity {
    public Uri mImageUri = null,imageuri;
    public String prodname, prodid, prodprice, prodqty, proddesc, pid;
    Button btn_add, btn_select;
    private EditText inputName, inputQty, inputPrice, inputDesc;
    DatabaseReference myref;
    StorageReference mstoreref;
    private FirebaseAuth.AuthStateListener authStateListener;
    private FirebaseAuth auth;
    private int GALLERY = 1, CAMERA = 2;
    private static final String SAVED_INSTANCE_URI = "uri";
    private String pictureFilePath;
    private ProgressBar progressBar;

    boolean f=false,t=true;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setLogo(R.drawable.ic_shop_cart);
        getSupportActionBar().setDisplayUseLogoEnabled(true);
        //get firebase auth instance
        auth = FirebaseAuth.getInstance();

        btn_select = (Button) findViewById(R.id.btn_select);
        btn_add = (Button) findViewById(R.id.add_prod_button);
        inputName = (EditText) findViewById(R.id.prod_name);
        inputPrice = (EditText) findViewById(R.id.prod_price);
        inputDesc = (EditText) findViewById(R.id.prod_desc);
        inputQty = (EditText) findViewById(R.id.prod_qty);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);

        if (savedInstanceState!=null){


            imageuri = Uri.parse(savedInstanceState.getString(SAVED_INSTANCE_URI));

        }

        btn_add.setEnabled(f);

        myref = FirebaseDatabase.getInstance().getReference().child("Products").push();
        mstoreref = FirebaseStorage.getInstance().getReference();
        pid = myref.getKey();


        btn_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showPictureDialog();
            }
        });


        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prodname = inputName.getText().toString();
                prodprice = inputPrice.getText().toString();
                proddesc = inputDesc.getText().toString();
                prodqty = inputQty.getText().toString();


                if (TextUtils.isEmpty(prodname)) {
                    Toast.makeText(getApplicationContext(), "Enter Product name!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(prodprice)) {
                    Toast.makeText(getApplicationContext(), "Enter Product Price!", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(proddesc)) {
                    Toast.makeText(getApplicationContext(), "Enter Product Description!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(prodqty)) {
                    Toast.makeText(getApplicationContext(), "Enter Product Quantity!", Toast.LENGTH_SHORT).show();
                    return;
                }



                Prod pinfo = new Prod(prodname, prodprice, prodqty, proddesc,pid);
                myref.setValue(pinfo)
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(AddProductActivity.this, "Product Added", Toast.LENGTH_SHORT).show();
                                    Log.e("taf",pid);
                                    Intent i = new Intent(AddProductActivity.this, NFCWriteActivity.class);
                                    i.putExtra("pid", pid);
                                    startActivity(i);
                                    finish();
                                } else {
                                    Toast.makeText(getApplicationContext(), "Cannot add Product", Toast.LENGTH_LONG).show();

                                }
                            }
                        });

            }
        });
    }

    @Override
    public void onBackPressed() {
        Intent i= new Intent(AddProductActivity.this,MainActivity.class);
        finish();
    }

    private void showPictureDialog() {
        AlertDialog.Builder pictureDialog = new AlertDialog.Builder(this);
        pictureDialog.setTitle("Select Action");
        String[] pictureDialogItems = {
                "Select photo from gallery",
                "Capture photo from camera"};
        pictureDialog.setItems(pictureDialogItems,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                progressBar.setVisibility(View.VISIBLE);
                                choosePhotoFromGallary();
                                break;
                            case 1:
                                progressBar.setVisibility(View.VISIBLE);
                                takePhotoFromCamera();
                                break;
                        }
                    }
                });
        pictureDialog.show();
    }

    public void choosePhotoFromGallary() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        startActivityForResult(galleryIntent, GALLERY);
    }

    private void takePhotoFromCamera() {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraIntent.putExtra( MediaStore.EXTRA_FINISH_ON_COMPLETION, true);
        if (cameraIntent.resolveActivity(getPackageManager()) != null) {
           // startActivityForResult(cameraIntent, CAMERA);
            File pictureFile = null;
            try {
                pictureFile = getPictureFile();
            } catch (IOException ex) {
                Toast.makeText(this,
                        "Photo file can't be created, please try again", Toast.LENGTH_SHORT).show();
                return;
            }
            if (pictureFile != null) {
                Uri photoURI = FileProvider.getUriForFile(this,
                        "com.techcyte.nfcshop.fileprovider", pictureFile);
                cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(cameraIntent, CAMERA);
            }
        }
    }

    private File getPictureFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        String pictureFile = "NFCSHOP_" + timeStamp;
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(pictureFile,  ".jpg", storageDir);
        pictureFilePath = image.getAbsolutePath();
        return image;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == this.RESULT_CANCELED) {
            Toast.makeText(AddProductActivity.this, "Result Cancelled!", Toast.LENGTH_SHORT).show();
            progressBar.setVisibility(View.GONE);
            return;
        }
        if (requestCode == GALLERY && resultCode==RESULT_OK) {
            if (data != null) {
                Uri contentURI = data.getData();
               imageUpload(contentURI);
            }

        } else if (requestCode == CAMERA && resultCode==RESULT_OK) {
            File imgFile = new  File(pictureFilePath);
            if(imgFile.exists())            {
                Uri picUri = Uri.fromFile(imgFile);
                Toast.makeText(AddProductActivity.this, "Image Captured", Toast.LENGTH_SHORT).show();
                imageUpload(picUri);

            }

            else{
                Toast.makeText(AddProductActivity.this, "Image Not Captured!", Toast.LENGTH_SHORT).show();
                progressBar.setVisibility(View.GONE);
            }
        }

    }

    public void imageUpload(Uri u){
        Uri imupload=u;
        StorageReference cref = mstoreref.child("Products").child(pid);
        cref.putFile(imupload).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Toast.makeText(AddProductActivity.this, "Image Uploaded", Toast.LENGTH_SHORT).show();
                progressBar.setVisibility(View.GONE);
                btn_add.setEnabled(t);
            }
        });

    }
}