package com.techcyte.nfcshop;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseListAdapter;
import com.firebase.ui.database.FirebaseListOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class ProductListActivity  extends AppCompatActivity {
    ListView listView;
    FirebaseAuth auth;
    private FirebaseAuth.AuthStateListener authListener;
    FirebaseListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_list);
        listView=(ListView) findViewById(R.id.list_product);
        auth = FirebaseAuth.getInstance();
        final String uid= auth.getUid();

        Query query= FirebaseDatabase.getInstance().getReference().child("Products");
        FirebaseListOptions<Prod> options =new FirebaseListOptions.Builder<Prod>()
                .setLayout(R.layout.product_list_item)
                .setQuery(query,Prod.class)
                .build();

        adapter = new FirebaseListAdapter(options) {
            @Override
            protected void populateView(@NonNull View v, @NonNull Object model, int position) {
                ImageView prodItemIcon = v.findViewById(R.id.productItemIcon);
                final TextView prodItemName = v.findViewById(R.id.productItemName);
                final TextView prodItemQuantity = v.findViewById(R.id.productItemOty);
                final TextView prodItemPrice = v.findViewById(R.id.productItemPrice);
                Button editFromProduct = v.findViewById(R.id.editFromProduct);
                Button removeFromProduct = v.findViewById(R.id.removeFromProduct);

                final Prod p=(Prod) model;
                final String pid =p.getProdid();

                StorageReference ref= FirebaseStorage.getInstance().getReference().child("Products").child(pid);
                GlideApp.with(getApplicationContext()).load(ref).fitCenter().into(prodItemIcon);
                prodItemName.setText(p.getProdname());
                prodItemPrice.setText("₹ "+p.getProdprice());
                prodItemQuantity.setText("Qty: "+p.getProdqty());

                editFromProduct.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i = new Intent(ProductListActivity.this, EditProductActivity.class);
                        i.putExtra("pid", pid);
                        startActivity(i);
                        finish();

                    }
                });

                removeFromProduct.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DatabaseReference delRef= FirebaseDatabase.getInstance().getReference().child("Products").child(p.getProdid());
                        delRef.removeValue();
                    }
                });




            }
        };

        listView.setAdapter(adapter);

    }


    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();

    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();

    }
}
