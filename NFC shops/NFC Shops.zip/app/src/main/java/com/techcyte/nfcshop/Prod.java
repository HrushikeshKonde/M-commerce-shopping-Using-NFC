package com.techcyte.nfcshop;

public class Prod {
    String prodname,prodprice,prodqty,proddesc,prodid;

    public Prod()
    {

    }
    public Prod(String prodname, String prodprice, String prodqty, String proddesc) {
        this.prodname = prodname;
        this.prodprice = prodprice;
        this.prodqty = prodqty;
        this.proddesc = proddesc;
    }

    public Prod(String prodname, String prodprice, String prodqty, String proddesc,String prodid) {
        this.prodname = prodname;
        this.prodprice = prodprice;
        this.prodqty = prodqty;
        this.proddesc = proddesc;
        this.prodid=prodid;
    }

    public Prod(Prod p)
    {
        prodname = p.prodname;
        prodprice = p.prodprice;
        proddesc = p.prodqty;
        prodqty= p.proddesc;
        prodid=p.prodid;
    }

    public String getProdname()
    {
        return prodname;
    }

    public String getProdprice()
    {
        return prodprice;
    }

    public String getProdqty()
    {
        return prodqty;
    }
    public String getProddesc()
    {
        return proddesc;
    }

    public String getProdid() {
        return prodid;
    }

}
