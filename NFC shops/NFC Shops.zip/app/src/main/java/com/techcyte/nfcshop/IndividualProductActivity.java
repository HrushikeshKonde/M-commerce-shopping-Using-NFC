package com.techcyte.nfcshop;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

public class IndividualProductActivity extends AppCompatActivity {
    int quantity;
    public int isCartEmpty;
    String pid="";
    Prod p;
    Button add, sub;
    String pname,pprice,pdes;
    TextView name, description, quantityView,priceView;
    FloatingActionButton addToCart, shoppingCart;
    ImageView productImage;
    ProgressBar progressBar;
    private FirebaseAuth auth;
    private FirebaseAuth.AuthStateListener authListener;
    DatabaseReference myref,cartref,statref;
    StorageReference ref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_individual_product);

        quantity=1;
        name = (TextView) findViewById(R.id.productNameIndividualProduct);
        description = (TextView) findViewById(R.id.productDescriptionIndividualProduct);
        quantityView = (TextView) findViewById(R.id.quantityProductPage);
        priceView = (TextView) findViewById(R.id.productPriceIndividualProduct);
        productImage=(ImageView) findViewById(R.id.productImageIndividualProduct);
        addToCart=(FloatingActionButton) findViewById(R.id.addToCartProductPage);
        shoppingCart=(FloatingActionButton) findViewById(R.id.cartProductPage);
        Intent i = getIntent();
        pid = i.getStringExtra("pid");
        auth = FirebaseAuth.getInstance();
        String uid= auth.getUid();
        myref=FirebaseDatabase.getInstance().getReference().child("Products").child(pid);
        cartref=FirebaseDatabase.getInstance().getReference().child("Cart").child(uid);
        statref=FirebaseDatabase.getInstance().getReference().child("Cart").child(uid).child("isCartEmpty");
        final DatabaseReference newRef=cartref.child("Products");
        ref= FirebaseStorage.getInstance().getReference().child("Products").child(pid);
//Task<Uri> u= ref.getDownloadUrl();
//String ur=u.toString();

//String url="https://firebasestorage.googleapis.com/v0/b/shop-7dbdc.appspot.com/o/Products%2F-La-KNRCmqwafmbL4pCx?alt=media&token=51f12555-7a97-4284-8e69-8bb2c73ab285";
       //  Picasso.get().load(ref.getDownloadUrl().toString()).into(productImage);
       //  Glide.with(this).load(ref).into(productImage);
//MyAppGlideModule GlideApp = new MyAppGlideModule();
        GlideApp.with(this).load(ref).fitCenter().into(productImage);
        //Glide.with(this).load(ref).into(productImage);
        progressBar = (ProgressBar) findViewById(R.id.individualProductPageProgressBar);
        progressBar.setVisibility(View.VISIBLE);

        statref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String check =  dataSnapshot.getValue().toString();
                if (check.equals("1"))
                {
                    isCartEmpty=1;
                }
                else{
                    isCartEmpty=0;
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        myref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot ) {
                p=dataSnapshot.getValue(Prod.class);
                //      u2= new Users(us);
                //     u2 = us;
                progressBar.setVisibility(View.GONE);

                pname=p.getProdname();
                pprice=p.getProdprice();
                pdes=p.getProddesc();
                description.setText(pdes);
                priceView.setText("₹ "+pprice);
                name.setText(pname);
                quantityView.setText(String.valueOf(quantity));

                //                data="\nName : "+name+"\nEmail : "+email+"\nPhone No : "+phoneno+"\nLocation : "+location;
                //              des.setText(data);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        add = (Button) findViewById(R.id.incrementQuantity);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                increment();
            }
        });

        sub = (Button) findViewById(R.id.decrementQuantity);
        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                decrement();
            }
        });

        addToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String pqty= quantityView.getText().toString();
//                Toast.makeText(getApplicationContext(), "Cart under Development", Toast.LENGTH_LONG).show();

                DatabaseReference intRef=newRef.child(pid);
                intRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(dataSnapshot.exists()){
                            Toast.makeText(getApplicationContext(), "Item already in Cart", Toast.LENGTH_LONG).show();

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
                cartref.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            statref.setValue("0");
                            DatabaseReference prodRef= newRef.child(pid);
                            int qty=Integer.valueOf(pqty);
                            int itmprice= Integer.valueOf(pprice);
                            float totalitemprice = qty*itmprice;
                            String item_total= String.valueOf(totalitemprice);
                        CartItem cartItem=new CartItem(pid,pname,pqty,pprice,item_total);
                            prodRef.setValue(cartItem);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });

        shoppingCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isCartEmpty==1){
                   // String s= Integer.toString(isCartEmpty);
                    Toast.makeText(getApplicationContext(), "Cart is Empty", Toast.LENGTH_LONG).show();


                }
                else{

                    startActivity(new Intent(IndividualProductActivity.this,CartActivity.class));

                 /*   newRef.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            long no = dataSnapshot.getChildrenCount();
                            String cartno= String.valueOf(no);
                            Toast.makeText(getApplicationContext(), "No of Items in Cart"+cartno, Toast.LENGTH_LONG).show();

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });*/
                }

            }
        });



    }

    void increment(){
        if (quantity < 50){
            quantity++;
            quantityView.setText(String.valueOf(quantity));
        } else {
            Toast.makeText(
                    getApplicationContext(),
                    "Limit of 50 products only",
                    Toast.LENGTH_SHORT)
                    .show();
        }
    }

    void decrement(){
        if (quantity > 1){
            quantity--;
            quantityView.setText(String.valueOf(quantity));
        }
    }

}
