package com.techcyte.nfcshop;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    TextView des;
    String uid,phoneno,name,email,location;
  String data;
  public Users us,u2;
    private FirebaseAuth auth;
    private FirebaseAuth.AuthStateListener authListener;
Button btnLogout,btnaddProduct,btnOrder,btnedit,btnFeedback,btninfo;
    FirebaseUser u;
//DatabaseReference myref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Get Firebase auth instance
        auth = FirebaseAuth.getInstance();
        u=auth.getCurrentUser();
        uid=u.getUid();
        btnLogout = findViewById(R.id.btnLogout);
        btnaddProduct = findViewById(R.id.btnaddProd);
        btnOrder = findViewById(R.id.btnOrders);
        btnedit = findViewById(R.id.btneditProd);
        btnFeedback = findViewById(R.id.btnFeedback);
        btninfo = findViewById(R.id.btnInfo);
        //des = (TextView) findViewById(R.id.des);
        //des.setText(uid);
        //myref=FirebaseDatabase.getInstance().getReference().child("Users").child(uid);

        authListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user == null) {
                    // user auth state is changed - user is null
                    // launch login activity
                    startActivity(new Intent(MainActivity.this, LoginActivity.class));
                    finish();
                }
            }
        };


        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, LoginActivity.class));
                auth.signOut();

            }
        });

        btnaddProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AddProductActivity.class));

            }
        });
        btnedit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder editDialog = new AlertDialog.Builder(MainActivity.this);
                editDialog.setTitle("Select Action");
                String[] editDialogItems = {
                        "Scan Product",
                        "List of Products"};
                editDialog.setItems(editDialogItems,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                switch (which) {
                                    case 0:
                                        startActivity(new Intent(MainActivity.this, EditScanProdcutActivity.class));
                                        break;
                                    case 1:
                                        startActivity(new Intent(MainActivity.this, ProductListActivity.class));
                                        break;
                                }
                            }
                        });
                editDialog.show();

            }
        });
        btnOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder orderDialog = new AlertDialog.Builder(MainActivity.this);
                orderDialog.setTitle("Select Action");
                String[] orderDialogItems = {
                        "Current Orders",
                        "Order History"};
                orderDialog.setItems(orderDialogItems,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                switch (which) {
                                    case 0:
                                        startActivity(new Intent(MainActivity.this, AdminOrderRequestActivity.class));
                                        break;
                                    case 1:
                                        startActivity(new Intent(MainActivity.this, AdminOrderHistoryActivity.class));

                                        break;
                                }
                            }
                        });
                orderDialog.show();

            }
        });
        btnFeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, FeedbackActivity.class));
//                Toast.makeText(MainActivity.this, "Feedback Activity Under Development", Toast.LENGTH_LONG).show();

            }
        });
        btninfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, InformativeActivity.class));
//                Toast.makeText(MainActivity.this, "Informative Activity Under Development", Toast.LENGTH_LONG).show();

            }
        });
        /*
        myref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot ) {
                us=dataSnapshot.getValue(Users.class);
           //      u2= new Users(us);
          //     u2 = us;
                 name=us.getName();
                email=us.getEmail();
                phoneno=us.getPhoneno();
                location=us.getLocation();
                data="\nName : "+name+"\nEmail : "+email+"\nPhone No : "+phoneno+"\nLocation : "+location;
                  des.setText(data);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
*/





    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public void onStart() {
        super.onStart();
        auth.addAuthStateListener(authListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        if (authListener != null) {
            auth.removeAuthStateListener(authListener);
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
    }
}

