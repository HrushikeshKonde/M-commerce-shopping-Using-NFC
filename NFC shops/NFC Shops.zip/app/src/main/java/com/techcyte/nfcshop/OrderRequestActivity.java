package com.techcyte.nfcshop;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseListAdapter;
import com.firebase.ui.database.FirebaseListOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class OrderRequestActivity  extends AppCompatActivity {
    ListView listView;
    FirebaseAuth auth;
    private FirebaseAuth.AuthStateListener authListener;
    FirebaseListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_request);
        listView=(ListView) findViewById(R.id.list_order_req);
        auth = FirebaseAuth.getInstance();
        final String uid= auth.getUid();

        Query query= FirebaseDatabase.getInstance().getReference().child("Orders").child("Users").child(uid).child("TempOrders");
        FirebaseListOptions<OrderReq> options =new FirebaseListOptions.Builder<OrderReq>()
                .setLayout(R.layout.order_request_item)
                .setQuery(query,OrderReq.class)
                .build();

        adapter = new FirebaseListAdapter(options) {
            @Override
            protected void populateView(@NonNull View v, @NonNull Object model, int position) {
                final TextView orderID = v.findViewById(R.id.orderID);
                final TextView timeStamp = v.findViewById(R.id.orderTime);
                final TextView total = v.findViewById(R.id.orderTotal);
                Button infoOrder = v.findViewById(R.id.openOrder);
                Button removeFromOrder = v.findViewById(R.id.deleteOrder);

                final OrderReq o=(OrderReq) model;
                final String oid =o.getOid();


                orderID.setText("ID: "+o.getOid());
                timeStamp.setText(o.getTimestamp());
                total.setText("₹ "+o.getTotal_price());

                infoOrder.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                            String status= o.getStatus();
                            String paymentStatus=o.getPaymentStatus();
                            if(status.equals("0")){
                                Intent i = new Intent(OrderRequestActivity.this, IndividualCurrentOrder.class);
                                i.putExtra("oid", oid);
                                startActivity(i);
                                finish();

                                Toast.makeText(getApplicationContext(),"Please Wait Order Not Yet Accepted",Toast.LENGTH_LONG).show();
                            }
                            else if(status.equals("1")){
                                Toast.makeText(getApplicationContext(),"Order Accepted",Toast.LENGTH_LONG).show();
                                if(paymentStatus.equals("1")){
                                    Toast.makeText(getApplicationContext(),"Please visit counter to pick-up your order",Toast.LENGTH_LONG).show();

                                    Intent i = new Intent(OrderRequestActivity.this, OtpCurrentOrderActivity.class);
                                    i.putExtra("oid", oid);
                                    startActivity(i);
                                    finish();


                                }
                                else if(paymentStatus.equals("0"))
                                {
                                    Intent i = new Intent(OrderRequestActivity.this, PaymentCurrentOrderActivity.class);
                                    i.putExtra("oid", oid);
                                    startActivity(i);
                                    finish();


                                    Toast.makeText(getApplicationContext(),"Payment Pending",Toast.LENGTH_LONG).show();

                                }

                            }
                    }
                });

                removeFromOrder.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DatabaseReference udelRef=FirebaseDatabase.getInstance().getReference().child("Orders").child("Users").child(uid).child("TempOrders").child(oid);
                        udelRef.removeValue();
                        DatabaseReference delRef= FirebaseDatabase.getInstance().getReference().child("Orders").child("Admin").child("TempOrders").child(oid);
                        delRef.removeValue();
                    }
                });




            }
        };

        listView.setAdapter(adapter);

    }


    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();

    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();

    }
}
