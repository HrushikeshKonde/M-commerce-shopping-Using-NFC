package com.techcyte.nfcshop;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseListAdapter;
import com.firebase.ui.database.FirebaseListOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseError;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.NotNull;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import static android.widget.Toast.*;

public class CartActivity extends AppCompatActivity {
ListView listView;
Button savecart;
TextView total;
FirebaseAuth auth;
float totalbill=0,datatotalbill=0;
int i=0;
float amount[]=new float[6];
private FirebaseAuth.AuthStateListener authListener;
FirebaseListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        listView=(ListView) findViewById(R.id.list_cart);
        savecart=(Button) findViewById(R.id.btn_savecart);
    //    total=(TextView) findViewById(R.id.tv_total);

        auth = FirebaseAuth.getInstance();
        final String uid= auth.getUid();

        Query query= FirebaseDatabase.getInstance().getReference().child("Cart").child(uid).child("Products");
        FirebaseListOptions<CartItem> options =new FirebaseListOptions.Builder<CartItem>()
                .setLayout(R.layout.cart_item)
                .setQuery(query,CartItem.class)
                .build();

        adapter = new FirebaseListAdapter(options) {
            @Override
            protected void populateView(@NonNull View v, @NonNull Object model, int position) {
                ImageView cartItemIcon = v.findViewById(R.id.cartItemIcon);
                final TextView cartItemName = v.findViewById(R.id.cartItemName);
                final TextView cartItemQuantity = v.findViewById(R.id.cartItemQuantity);
                final TextView cartItemPrice = v.findViewById(R.id.cartItemPrice);
                final TextView cartItemTotal = v.findViewById(R.id.cartItemTotal);
                Button cartdecrementQuantity = v.findViewById(R.id.cartdecrementQuantity);
                Button cartincrementQuntity = v.findViewById(R.id.cartincrementQuantity);
                Button removeFromCart = v.findViewById(R.id.removeFromCart);

                final CartItem c=(CartItem) model;
                final String pid =c.getId();

                DatabaseReference myRef= FirebaseDatabase.getInstance().getReference().child("Products").child(pid);
                final DatabaseReference cart= FirebaseDatabase.getInstance().getReference().child("Cart").child(uid);
                final StorageReference ref= FirebaseStorage.getInstance().getReference().child("Products").child(pid);

                GlideApp.with(getApplicationContext()).load(ref).fitCenter().into(cartItemIcon);

                cartItemQuantity.setText(c.getQty());

                cartdecrementQuantity.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        totalbill=0;
                        int qty =Integer.valueOf((String) cartItemQuantity.getText());
                        if (qty > 1){

                            qty--;
                            cartItemQuantity.setText(String.valueOf(qty));
                            DatabaseReference qtyRef= FirebaseDatabase.getInstance().getReference().child("Cart").child(uid).child("Products").child(c.getId()).child("qty");
                            qtyRef.setValue(String.valueOf(qty));
                        }

                    }
                });

                cartincrementQuntity.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        totalbill=0;
                        int qty =Integer.valueOf((String) cartItemQuantity.getText());
                        if (qty < 50){
                            qty++;
                            cartItemQuantity.setText(String.valueOf(qty));
                            DatabaseReference qtyRef= FirebaseDatabase.getInstance().getReference().child("Cart").child(uid).child("Products").child(c.getId()).child("qty");
                            qtyRef.setValue(String.valueOf(qty));
                        } else {
                            makeText(
                                    getApplicationContext(),
                                    "Limit of 50 products only",
                                    LENGTH_SHORT)
                                    .show();
                        }
                    }
                });

                removeFromCart.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        totalbill=0;

                        DatabaseReference delRef= FirebaseDatabase.getInstance().getReference().child("Cart").child(uid).child("Products").child(c.getId());
                        delRef.removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if(task.isSuccessful()){
                                    DatabaseReference newRef=FirebaseDatabase.getInstance().getReference().child("Cart").child(uid).child("Products");
                                    newRef.addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                            long no = dataSnapshot.getChildrenCount();
                                            String cartno= String.valueOf(no);

                                         //   Toast.makeText(getApplicationContext(), "No of Items in Cart"+cartno, Toast.LENGTH_LONG).show();

                                            if(cartno.equals("0")){
                                                Toast.makeText(getApplicationContext(), "Your cart is empty", Toast.LENGTH_LONG).show();
                                                cart.child("CartTotal").setValue(String.valueOf("0"));
                                                cart.child("isCartEmpty").setValue(String.valueOf("1"));
                                                startActivity(new Intent(CartActivity.this, UserMainActivity.class));
                                                finish();
                                            }
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError databaseError) {

                                        }
                                    });
                                }
                            }
                        });
                    }
                });
                //  cartItemTotal.setText("4565");



                myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        Prod p=dataSnapshot.getValue(Prod.class);
                        cartItemName.setText(p.getProdname());
                        cartItemPrice.setText(p.getProdprice());
                        String tot_qty= p.getProdqty();
                        DatabaseReference prodnam= FirebaseDatabase.getInstance().getReference().child("Cart").child(uid).child("Products").child(c.getId()).child("name");
                        prodnam.setValue(String.valueOf(p.getProdname()));

                        DatabaseReference prodpri= FirebaseDatabase.getInstance().getReference().child("Cart").child(uid).child("Products").child(c.getId()).child("price");
                        prodpri.setValue(String.valueOf(p.getProdprice()));

                        int totqty= Integer.valueOf(p.getProdqty());
                        int qty=Integer.valueOf(c.getQty());
                        int itmprice= Integer.valueOf(p.getProdprice());
                        float totalitemprice = qty*itmprice;
                        String titm= String.valueOf(totalitemprice);
                        cartItemTotal.setText(titm);

                        DatabaseReference prodtot= FirebaseDatabase.getInstance().getReference().child("Cart").child(uid).child("Products").child(c.getId()).child("item_total");
                        prodtot.setValue(String.valueOf(titm));
                        DatabaseReference prodtotqty= FirebaseDatabase.getInstance().getReference().child("Cart").child(uid).child("Products").child(c.getId()).child("total_qty");
                        prodtotqty.setValue(tot_qty);
                       // float half = totalitemprice/2;
                       // totalbill =totalbill+totalitemprice;

                       // String billAmount=String.valueOf(totalbill);
                        //cart.child("CartTotal").setValue(String.valueOf(billAmount));
                        //total.setText("₹ "+billAmount);


                        //totalbill=0;
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }
        };



    listView.setAdapter(adapter);


        savecart.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(CartActivity.this, SaveCartActivity.class));
            }
        });

    }


    @Override
    protected void onStart() {
        super.onStart();
    adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
    adapter.stopListening();
    }
}
