package com.techcyte.nfcshop;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

public class TestActivity extends AppCompatActivity {
String pid;
EditText prodid;
Button submit;
ProgressBar progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);

        submit = (Button) findViewById(R.id.sbm);
        prodid = (EditText) findViewById(R.id.ipid);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                progressBar.setVisibility(View.VISIBLE);
                pid = prodid.getText().toString();


                if (TextUtils.isEmpty(pid)) {
                    Toast.makeText(getApplicationContext(), "Enter Product ID!", Toast.LENGTH_SHORT).show();
                    progressBar.setVisibility(View.GONE);
                    return;
                }

                Intent i = new Intent(TestActivity.this, IndividualProductActivity.class);
                i.putExtra("pid", pid);
                startActivity(i);
                finish();




            }
        });
    }
}
