package com.techcyte.nfcshop;

public class OrderReq {
    String uid,oid,total_price,status,timestamp,paymentStatus;

    public OrderReq(){

    }
    public OrderReq(String oid,String status,String timestamp,String total_price,String uid)
    {
        this.oid=oid;
        this.status=status;
        this.timestamp=timestamp;
        this.total_price=total_price;
        this.uid=uid;
    }

    public OrderReq(String oid,String status,String timestamp,String total_price,String uid,String paymentStatus)
    {
        this.oid=oid;
        this.status=status;
        this.timestamp=timestamp;
        this.total_price=total_price;
        this.uid=uid;
        this.paymentStatus=paymentStatus;
    }
    public OrderReq(OrderReq o) {
        oid = o.oid;
        status = o.status;
        timestamp = o.timestamp;
        total_price = o.total_price;
        uid = o.uid;
        paymentStatus=o.paymentStatus;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public String getOid() {
        return oid;
    }

    public String getUid() {
        return uid;
    }

    public String getStatus() {
        return status;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public String getTotal_price() {
        return total_price;
    }


}
