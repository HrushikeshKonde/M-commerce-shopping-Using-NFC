package com.techcyte.nfcshop;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.*;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class ChangePasswordActivity extends AppCompatActivity {
    String newp, rnewp;
    EditText np, rnp;
    Button change;
    FirebaseUser u;
    FirebaseAuth auth;
    private ProgressBar progressBar;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        auth = FirebaseAuth.getInstance();
        u=auth.getCurrentUser();

        rnp = (EditText) findViewById(R.id.re_new_pass);
        change = (Button) findViewById(R.id.chn);
        np = (EditText) findViewById(R.id.new_pass);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);

        change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                progressBar.setVisibility(View.VISIBLE);
                newp = np.getText().toString();
                rnewp = rnp.getText().toString();


                if (TextUtils.isEmpty(newp)) {
                    Toast.makeText(getApplicationContext(), "Enter Password!", Toast.LENGTH_SHORT).show();
                    progressBar.setVisibility(View.GONE);
                    return;
                }

                if (TextUtils.isEmpty(rnewp)) {
                    Toast.makeText(getApplicationContext(), "Enter Password!", Toast.LENGTH_SHORT).show();
                    progressBar.setVisibility(View.GONE);
                    return;
                }
                if (!TextUtils.equals(newp,rnewp)) {
                    Toast.makeText(getApplicationContext(), "Both Password does not match!", Toast.LENGTH_SHORT).show();
                    progressBar.setVisibility(View.GONE);

                    return;
                }


                u.updatePassword(newp)
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {

                                    Toast.makeText(ChangePasswordActivity.this, "Password is updated!", Toast.LENGTH_SHORT).show();
                                    progressBar.setVisibility(View.GONE);
                                    finish();
                                    startActivity(new Intent(ChangePasswordActivity.this, UserMainActivity.class));

                                } else {
                                    Toast.makeText(ChangePasswordActivity.this, "Failed to update password!", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(ChangePasswordActivity.this, LoginActivity.class));
                                    Snackbar.make(v, "Please login again to change your password", Snackbar.LENGTH_LONG).show();
                                    auth.signOut();
                                    progressBar.setVisibility(View.GONE);
                                }
                            }
                        });
            }
        });

    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(ChangePasswordActivity.this, UserMainActivity.class));
        finish();
        super.onBackPressed();
    }
}