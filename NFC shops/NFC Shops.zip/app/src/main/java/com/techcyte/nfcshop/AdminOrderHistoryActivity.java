package com.techcyte.nfcshop;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseListAdapter;
import com.firebase.ui.database.FirebaseListOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

public class AdminOrderHistoryActivity  extends AppCompatActivity {
    ListView listView;
    FirebaseAuth auth;
    private FirebaseAuth.AuthStateListener authListener;
    FirebaseListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_order_history);
        listView=(ListView) findViewById(R.id.list_order_req);


        Query query= FirebaseDatabase.getInstance().getReference().child("Orders").child("Admin").child("Orders");
        FirebaseListOptions<OrderReq> options =new FirebaseListOptions.Builder<OrderReq>()
                .setLayout(R.layout.order_request_item)
                .setQuery(query,OrderReq.class)
                .build();

        adapter = new FirebaseListAdapter(options) {
            @Override
            protected void populateView(@NonNull View v, @NonNull Object model, int position) {
                final TextView orderID = v.findViewById(R.id.orderID);
                final TextView timeStamp = v.findViewById(R.id.orderTime);
                final TextView total = v.findViewById(R.id.orderTotal);
                Button infoOrder = v.findViewById(R.id.openOrder);
                Button removeFromOrder = v.findViewById(R.id.deleteOrder);

                final OrderReq o=(OrderReq) model;
                final String oid =o.getOid();
                final String uid =o.getUid();

                orderID.setText("ID: "+o.getOid());
                timeStamp.setText(o.getTimestamp());
                total.setText("₹ "+o.getTotal_price());

                infoOrder.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                                Intent i = new Intent(AdminOrderHistoryActivity.this, IndividualAdminOrderActivty.class);
                                i.putExtra("oid", oid);
                                startActivity(i);
                                finish();

                                Toast.makeText(getApplicationContext(),"Payment Pending",Toast.LENGTH_LONG).show();


                    }
                });

                removeFromOrder.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DatabaseReference udelRef=FirebaseDatabase.getInstance().getReference().child("Orders").child("Users").child(uid).child("Orders").child(oid);
                        udelRef.removeValue();
                        DatabaseReference delRef= FirebaseDatabase.getInstance().getReference().child("Orders").child("Admin").child("Orders").child(oid);
                        delRef.removeValue();
                    }
                });




            }
        };

        listView.setAdapter(adapter);

    }


    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();

    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();

    }
}
