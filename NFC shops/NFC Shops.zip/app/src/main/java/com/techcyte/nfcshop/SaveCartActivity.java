package com.techcyte.nfcshop;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseListAdapter;
import com.firebase.ui.database.FirebaseListOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseError;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.NotNull;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.text.SimpleDateFormat;
import java.util.Date;

import static android.widget.Toast.*;

public class SaveCartActivity extends AppCompatActivity {
    ListView listView;
    Button order;
    TextView total;
    FirebaseAuth auth;
    float totalbill=0,datatotalbill=0;
    int i=0;
    float amount[]=new float[6];
    private FirebaseAuth.AuthStateListener authListener;
    FirebaseListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_save_cart);
        listView=(ListView) findViewById(R.id.list_cart);
        order=(Button) findViewById(R.id.btn_placeorder);
        total=(TextView) findViewById(R.id.tv_total);

        auth = FirebaseAuth.getInstance();
        final String uid= auth.getUid();

        Query query= FirebaseDatabase.getInstance().getReference().child("Cart").child(uid).child("Products");
        FirebaseListOptions<CartItem> options =new FirebaseListOptions.Builder<CartItem>()
                .setLayout(R.layout.save_cart_item)
                .setQuery(query,CartItem.class)
                .build();

        adapter = new FirebaseListAdapter(options) {
            @Override
            protected void populateView(@NonNull View v, @NonNull Object model, int position) {
                ImageView cartItemIcon = v.findViewById(R.id.cartItemIcon);
                final TextView cartItemName = v.findViewById(R.id.cartItemName);
                final TextView cartItemQuantity = v.findViewById(R.id.cartItemQuantity);
                final TextView cartItemPrice = v.findViewById(R.id.cartItemPrice);
                final TextView cartItemTotal = v.findViewById(R.id.cartItemTotal);

                final CartItem c=(CartItem) model;
                final String pid =c.getId();

                DatabaseReference myRef= FirebaseDatabase.getInstance().getReference().child("Products").child(pid);
                final DatabaseReference cart= FirebaseDatabase.getInstance().getReference().child("Cart").child(uid);
                final StorageReference ref= FirebaseStorage.getInstance().getReference().child("Products").child(pid);

                GlideApp.with(getApplicationContext()).load(ref).fitCenter().into(cartItemIcon);

                cartItemQuantity.setText(" x "+c.getQty());


                myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        Prod p=dataSnapshot.getValue(Prod.class);
                        cartItemName.setText(p.getProdname());
                        cartItemPrice.setText(" ₹ "+p.getProdprice());
                        String tot_qty= p.getProdqty();

                        int totqty= Integer.valueOf(p.getProdqty());
                        int qty=Integer.valueOf(c.getQty());
                        int itmprice= Integer.valueOf(p.getProdprice());
                        float totalitemprice = qty*itmprice;
                        String titm= String.valueOf(totalitemprice);
                        cartItemTotal.setText("  ₹ "+titm);

                        // float half = totalitemprice/2;
                         totalbill =totalbill+totalitemprice;

                         String billAmount=String.valueOf(totalbill);
                         cart.child("CartTotal").setValue(String.valueOf(billAmount));
                         total.setText("₹ "+billAmount);
                            DatabaseReference prodtotqty= FirebaseDatabase.getInstance().getReference().child("Cart").child(uid).child("Products").child(c.getId()).child("total_qty");
                            prodtotqty.setValue(tot_qty);


                        //totalbill=0;
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }
        };



        listView.setAdapter(adapter);


        order.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
             //   String t = (String) total.getText();
                final DatabaseReference orderRef=FirebaseDatabase.getInstance().getReference().child("Orders");
                DatabaseReference userOrderRef=orderRef.child("Users").child(uid).child("Orders").push();
                final String uoid=userOrderRef.getKey();
                final DatabaseReference newOrder = FirebaseDatabase.getInstance().getReference().child("Orders").child("Users").child(uid).child("TempOrders").child(uoid);
                final DatabaseReference adminOrderRef=orderRef.child("Admin").child("TempOrders").child(uoid);

                DatabaseReference cartRef=FirebaseDatabase.getInstance().getReference().child("Cart").child(uid).child("Products");
                cartRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        int placeOrder=0;
                        for(DataSnapshot cartShot : dataSnapshot.getChildren()){
                            String qty=cartShot.child("qty").getValue().toString();
                            String total_qty=cartShot.child("total_qty").getValue().toString();

                            int itqt=Integer.valueOf(qty);
                            int totqt=Integer.valueOf(total_qty);
                            if(itqt<=totqt) {
                                placeOrder=1;
                            }
                            else{
                                placeOrder=0;
                                break;
                            }
                        }

                        if (placeOrder == 1){

                            for(DataSnapshot cartSnap : dataSnapshot.getChildren()){
                                String id=cartSnap.child("id").getValue().toString();
                                String name=cartSnap.child("name").getValue().toString();
                                String qty=cartSnap.child("qty").getValue().toString();
                                String total_qty=cartSnap.child("total_qty").getValue().toString();
                                String price=cartSnap.child("price").getValue().toString();
                                String item_total=cartSnap.child("item_total").getValue().toString();

                                int itqt=Integer.valueOf(qty);
                                int totqt=Integer.valueOf(total_qty);


                                    CartItem prod = new CartItem(id, name, qty, price, item_total);

                                    DatabaseReference newOrdProd = newOrder.child("Products").child(id);
                                    newOrdProd.setValue(prod);
                                    DatabaseReference anewOrder = adminOrderRef.child("Products").child(id);
                                    anewOrder.setValue(prod);

                                    DatabaseReference crprod = FirebaseDatabase.getInstance().getReference().child("Products").child(id);
                                    DatabaseReference currentProd = crprod.child("prodqty");
                                    int newqty = totqt - itqt;
                                    String nqty = String.valueOf(newqty);
                                    currentProd.setValue(nqty);
                                    Toast.makeText(getApplicationContext(), "Order Placed", Toast.LENGTH_LONG).show();

                            }


                            final DatabaseReference userCart=FirebaseDatabase.getInstance().getReference().child("Cart").child(uid);
                            userCart.child("Products").removeValue();
                            userCart.child("isCartEmpty").setValue("1");

                            String total_amount=total.getText().toString();
                            String tamt=total_amount.replace("₹ ","");

                            String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(new Date());
                            String status = "0";

                          adminOrderRef.child("uid").setValue(uid);
                            adminOrderRef.child("timestamp").setValue(timeStamp);
                            adminOrderRef.child("total_price").setValue(tamt);
                            adminOrderRef.child("oid").setValue(uoid);
                            adminOrderRef.child("status").setValue("0");
                            adminOrderRef.child("paymentStatus").setValue("0");
                            newOrder.child("uid").setValue(uid);
                            newOrder.child("oid").setValue(uoid);
                            newOrder.child("status").setValue("0");
                            newOrder.child("paymentStatus").setValue("0");
                            newOrder.child("total_price").setValue(tamt);
                            newOrder.child("timestamp").setValue(timeStamp);

                            userCart.child("CartTotal").setValue("0");
                            finish();
                            startActivity(new Intent(SaveCartActivity.this,OrderRequestActivity.class));
                        }
                        else{
                                Toast.makeText(getApplicationContext(),"Insufficient Quantity",Toast.LENGTH_LONG).show();
                                finish();
                                startActivity(new Intent(SaveCartActivity.this,CartActivity.class));

                        }


                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
               //             Toast.makeText(getApplicationContext(),"Placing Order of Rs. "+t,Toast.LENGTH_LONG).show();
                //           startActivity(new Intent(CartActivity.this, SaveCartActivity.class));
            }
        });

    }


    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}
