package com.techcyte.nfcshop;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseListAdapter;
import com.firebase.ui.database.FirebaseListOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class IndividualAcceptCurrentOrder extends AppCompatActivity {
    TextView orderID,userID,uNo,uName,time,total;
    ListView listView;
    Button accept;
    String uid,oid,total_price,status,timestamp,paymentStatus,name,phno;
    FirebaseListAdapter adapter;
    private FirebaseAuth auth;
    private FirebaseAuth.AuthStateListener authListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_individual_accept_current_order);


        Intent i = getIntent();
        oid = i.getStringExtra("oid");

        accept = (Button) findViewById(R.id.btn_accept);
        orderID = (TextView) findViewById(R.id.tv_oid);
        userID = (TextView) findViewById(R.id.tv_uid);
        uNo = (TextView) findViewById(R.id.tv_uNo);
        uName = (TextView) findViewById(R.id.tv_name);
        time = (TextView) findViewById(R.id.tv_timestamp);
        total = (TextView) findViewById(R.id.tv_total);

        listView =(ListView) findViewById(R.id.list_order);
        orderID.setText(oid);
        DatabaseReference orderRef= FirebaseDatabase.getInstance().getReference().child("Orders").child("Admin").child("TempOrders").child(oid);
        orderRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                timestamp=dataSnapshot.child("timestamp").getValue().toString();
                total_price=dataSnapshot.child("total_price").getValue().toString();
                uid=dataSnapshot.child("uid").getValue().toString();
                userID.setText(uid);
                time.setText(timestamp);
                total.setText(total_price);
                DatabaseReference userRef=FirebaseDatabase.getInstance().getReference().child("Users").child(uid);
                userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot userSnapshot) {
                        name=userSnapshot.child("name").getValue().toString();
                        phno=userSnapshot.child("phoneno").getValue().toString();
                        uName.setText(name);
                        uNo.setText(phno);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });




        Query query= FirebaseDatabase.getInstance().getReference().child("Orders").child("Admin").child("TempOrders").child(oid).child("Products");
        FirebaseListOptions<CartItem> options =new FirebaseListOptions.Builder<CartItem>()
                .setLayout(R.layout.save_cart_item)
                .setQuery(query,CartItem.class)
                .build();

        adapter = new FirebaseListAdapter(options) {
            @Override
            protected void populateView(@NonNull View v, @NonNull Object model, int position) {
                ImageView cartItemIcon = v.findViewById(R.id.cartItemIcon);
                final TextView cartItemName = v.findViewById(R.id.cartItemName);
                final TextView cartItemQuantity = v.findViewById(R.id.cartItemQuantity);
                final TextView cartItemPrice = v.findViewById(R.id.cartItemPrice);
                final TextView cartItemTotal = v.findViewById(R.id.cartItemTotal);

                final CartItem c=(CartItem) model;
                final String pid =c.getId();
                ;
                final StorageReference ref= FirebaseStorage.getInstance().getReference().child("Products").child(pid);

                GlideApp.with(getApplicationContext()).load(ref).fitCenter().into(cartItemIcon);

                cartItemQuantity.setText(" x "+c.getQty());
                cartItemName.setText(c.getName());
                cartItemPrice.setText(" ₹ "+c.getPrice());
                cartItemTotal.setText("  ₹ "+c.getItem_total());


            }
        };
        listView.setAdapter(adapter);

        accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user=userID.getText().toString();
                DatabaseReference userOrderRef=FirebaseDatabase.getInstance().getReference().child("Orders").child("Users").child(user).child("TempOrders").child(oid).child("status");
                userOrderRef.setValue("1");
                DatabaseReference adminOrderRef=FirebaseDatabase.getInstance().getReference().child("Orders").child("Admin").child("TempOrders").child(oid).child("status");
                adminOrderRef.setValue("1");
                Intent i = new Intent(IndividualAcceptCurrentOrder.this, AdminOrderRequestActivity.class);
                finish();
                startActivity(i);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}

