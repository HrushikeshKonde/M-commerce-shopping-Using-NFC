package com.techcyte.nfcshop;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.techcyte.nfcshop.factory.NDEFRecordFactory;
import com.techcyte.nfcshop.model.BaseRecord;
import com.techcyte.nfcshop.model.RDTSpRecord;

import java.util.ArrayList;
import java.util.List;

import static android.nfc.NfcAdapter.getDefaultAdapter;

public class ScanProductActivity extends Activity {

    private NfcAdapter nfcAdpt=null;
    PendingIntent nfcPendingIntent;
    IntentFilter[] intentFiltersArray;

    //    private TextView recNumberTxt;
    private ListView lView;
    TextView tView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan_product);

        lView = findViewById(R.id.recList);

//        recNumberTxt = findViewById(R.id.recNumber);

        nfcAdpt = getDefaultAdapter(this);

        // Check if the smartphone has NFC
        if (nfcAdpt == null) {
            Toast.makeText(this, "NFC not supported", Toast.LENGTH_LONG).show();
            finish();
        }

        // Check if NFC is enabled
        if (!nfcAdpt.isEnabled()) {
            Toast.makeText(this, "Enable NFC before using the app", Toast.LENGTH_LONG).show();
        }

        Intent nfcIntent = new Intent(this, getClass());
        nfcIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);

        nfcPendingIntent =
                PendingIntent.getActivity(this, 0, nfcIntent, 0);

        // Create an Intent Filter limited to the URI or MIME type to
        // intercept TAG scans from.
        IntentFilter tagIntentFilter =
                new IntentFilter(NfcAdapter.ACTION_NDEF_DISCOVERED);
        try {
            //tagIntentFilter.addDataScheme("http");
            // tagIntentFilter.addDataScheme("vnd.android.nfc");
            tagIntentFilter.addDataScheme("tel");
            //tagIntentFilter.addDataType("text/plain");
            intentFiltersArray = new IntentFilter[]{tagIntentFilter};
        }
        catch (Throwable t) {
            t.printStackTrace();
        }
    }

    @Override
    public void onNewIntent(Intent intent) {
        Log.d("Nfc", "New intent");
        getTag(intent);
    }

    private void handleIntent(Intent i) {

        Log.d("NFC", "Intent [" + i + "]");

        getTag(i);
    }



    @Override
    protected void onResume() {
        super.onResume();

        nfcAdpt.enableForegroundDispatch(
                this,
                // Intent that will be used to package the Tag Intent.
                nfcPendingIntent,
                // Array of Intent Filters used to declare the Intents you
                // wish to intercept.
                intentFiltersArray,
                // Array of Tag technologies you wish to handle.
                null);
        handleIntent(getIntent());
    }


    @Override
    protected void onPause() {
        super.onPause();
        nfcAdpt.disableForegroundDispatch(this);
    }




    private void getTag(Intent i) {
        if (i == null)
            return ;

        String type = i.getType();
        String action = i.getAction();
        List<BaseRecord> dataList = new ArrayList<BaseRecord>();

        if (NfcAdapter.ACTION_NDEF_DISCOVERED.equals(action)) {
            Log.d("Nfc", "Action NDEF Found");
            Parcelable[] parcs = i.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);

            // List record


            for (Parcelable p : parcs) {
                NdefMessage msg = (NdefMessage) p;
//                final int numRec = msg.getRecords().length;
//                recNumberTxt.setText(String.valueOf(numRec));

                NdefRecord[] records = msg.getRecords();
                for (NdefRecord record: records) {
                    BaseRecord result = NDEFRecordFactory.createRecord(record);
                    if (result instanceof RDTSpRecord)
                        dataList.addAll( ((RDTSpRecord) result).records);
                    else
                        dataList.add(result);

                }
            }

            NdefAdapter adpt = new NdefAdapter(dataList);
            lView.setAdapter(adpt);
        }

    }





    // ListView adapter
    class NdefAdapter extends ArrayAdapter<BaseRecord> {
        List<BaseRecord> recordList;

        public NdefAdapter(List<BaseRecord> recordList) {
            super(ScanProductActivity.this, R.layout.record_layout, recordList);
            this.recordList = recordList;
        }

        @Override
        public int getCount() {
            return recordList.size();
        }

        @Override
        public BaseRecord getItem(int position) {
            return recordList.get(position);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View v = convertView;
            Log.d("Nfc","Get VIew");
            if (v == null) {
                LayoutInflater inf = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                v = inf.inflate(R.layout.record_layout, null);
            }

//            TextView recContentTxT = v.findViewById(R.id.recCont);
            tView = findViewById(R.id.test);
            BaseRecord record = recordList.get(position);
            //          tnfTxt.setText("" + record.tnf);
//            headTxt.setText("MB:" + record.MB + " ME:" + record.ME + " SR:" + record.SR);

//            recContentTxT.setText(record.toString());
            tView.setText(record.toString());
            String pid=record.toString();
            Intent i = new Intent(ScanProductActivity.this, IndividualProductActivity.class);
            i.putExtra("pid", pid);
            startActivity(i);
            finish();
            // Toast.makeText(ScanProductActivity.this, "ID"+record.toString(), Toast.LENGTH_LONG).show();
            return v;

        }




        @Override
        public long getItemId(int position) {
            return recordList.get(position).hashCode();
        }
    }



}
