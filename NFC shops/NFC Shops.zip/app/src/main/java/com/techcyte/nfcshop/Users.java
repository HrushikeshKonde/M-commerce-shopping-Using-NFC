package com.techcyte.nfcshop;
public class Users {
    String phoneno;
    String name;
    String email;
    String password;
    String location;
    String admin;
    public Users()
    {

    }
    public Users(String phoneno,String name,String email,String password,String location,String admin)
    {
        this.phoneno = phoneno;
        this.name = name;
        this.email = email;
        this.password=password;
        this.location=location;
        this.admin=admin;
    }

    public Users(Users u)
    {
        phoneno = u.phoneno;
        name = u.name;
        email = u.email;
        password= u.password;
        location= u.location;
        admin=u.admin;
    }

    public String getPhoneno() {
        return phoneno;
    }

    public String getName() {
        return name;
    }
    public String getAdmin(){return admin;}
    public String getEmail() {
        return email;
    }
    public String getPassword() {
        return password;
    }
    public String getLocation() {
        return location;
    }
}